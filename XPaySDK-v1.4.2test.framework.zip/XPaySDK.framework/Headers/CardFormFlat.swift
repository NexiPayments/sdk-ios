//
//  CardFormFlat.swift
//  XpaySDK
//
//  Created by Nexi Payments Spa on 04/09/18.
//  Copyright © 2018 Nexi Payments Spa. All rights reserved.
//

import UIKit

@objc(CardFormFlat)
@IBDesignable
public class CardFormFlat: CardFormBase {

    @IBOutlet weak var textCardNumber: ImageTextField!
    @IBOutlet weak var textCardExpire: UITextField!
    @IBOutlet weak var textCardCvc: UITextField!
    
    internal let viewName = "CardFormFlatView"
    
    override public func prepareForInterfaceBuilder() {
        setNibName(viewName)
        super.prepareForInterfaceBuilder()
    }
    
    override public func awakeFromNib() {
        setNibName(viewName)
        super.awakeFromNib()
        setDelegates()
    }
    
    internal override func setKeyboard() {
        textCardNumber.inputView = _keyboard
        textCardExpire.inputView = _keyboard
        textCardCvc.inputView = _keyboard
    }
    
    override func xibSetup() {
        super.xibSetup()
        textCardCvc.addLineToView(position: .LINE_POSITION_BOTTOM, color: fontColor, width: 0.5)
        textCardNumber.addLineToView(position: .LINE_POSITION_BOTTOM, color: fontColor, width: 0.5)
        textCardExpire.addLineToView(position: .LINE_POSITION_BOTTOM, color: fontColor, width: 0.5)
    }
    
    private func setDelegates() {
        // editingChanged
        textCardNumber.addTarget(self, action: #selector(textFieldDidChange(_:)), for: .editingChanged)
        textCardNumber.addTarget(self, action: #selector(textFieldFinishEditing(_:)), for: .editingDidEnd)
        textCardExpire.addTarget(self, action: #selector(textFieldDidChange(_:)), for: .editingChanged)
        textCardCvc.addTarget(self, action: #selector(textFieldDidChange(_:)), for: .editingChanged)
        // editingDidBegin
        textCardNumber.addTarget(self, action: #selector(textFieldDidBeginEditing(_:)), for: .editingDidBegin)
        textCardExpire.addTarget(self, action: #selector(textFieldDidBeginEditing(_:)), for: .editingDidBegin)
        textCardCvc.addTarget(self, action: #selector(textFieldDidBeginEditing(_:)), for: .editingDidBegin)
    }
    
    @objc func textFieldDidChange(_ textField: UITextField) {
        let text = textField.text
        switch textField {
        case textCardNumber:
            presenter?.updateCard(number: text, for: textField)
        case textCardExpire:
            presenter?.updateCard(expire: text)
        default:
            presenter?.updateCard(cvc: text)
        }
    }
    
    @objc func textFieldFinishEditing(_ textField: UITextField) {
        let text = textField.text
        switch textField {
        default:
            presenter?.check(number: text)
        }
    }
    
    override public func display(number: String?) {
        textCardNumber.text = number
    }
    
    override public func display(expire: String?) {
        textCardExpire.text = expire
    }
    
    override public func display(cvc: String?) {
        textCardCvc.text = cvc
    }
    
    override public func displayNumber(error: String?, color: UIColor) {
        textCardNumber.textColor = color
    }
    
    override public func displayExpire(error: String?, color: UIColor) {
        textCardExpire.textColor = color
    }
    
    override public func displayCvc(error: String?, color: UIColor) {
        textCardCvc.textColor = color
    }
    
    override public func display(brand: CardBrand) {
        textCardNumber.leftImage = brand.image()
    }
    
    override public func number(animation: ImageTextField.TextAnimation?) {
        if shakeOnErrors {
            textCardNumber.display(animation!)
        }
    }
    
    override public func update(fontColor: UIColor) {
        textCardNumber.textColor = fontColor
        textCardExpire.textColor = fontColor
        textCardCvc.textColor = fontColor
    }
    
    override func onDelete(characters count: Int) {
        super.onDelete(characters: count) 
    }
}
